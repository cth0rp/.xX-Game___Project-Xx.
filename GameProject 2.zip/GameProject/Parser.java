import java.util.Scanner;

/**
 * By Christopher Thorp
 * By Oliver CZ
 */
public class Parser 
{
    // holds all valid command words
    private CommandWords commands;  

    /**
     * Create a parser.
     */
    public Parser() 
    {
        commands = new CommandWords();
    }

    /**
     * Parse the given input line.
     * @param inputLine The line to be parsed.
     * @return The next command from the user.
     */
    public Command getCommand(String inputLine) 
    {
        String word1 = null;
        String word2 = null;

        // Find up to two words on the line.
        Scanner tokenizer = new Scanner(inputLine);
        if(tokenizer.hasNext()) 
        {
            word1 = tokenizer.next();      // get first word
            if(tokenizer.hasNext()) 
            {
                word2 = tokenizer.next();      // get second word
                // note: If more than 2 words are input, the extra ones are ignored.
            }
        }

        // Now check whether this word is known. If so, create a command
        // with it. If not, create a "null" command (for unknown command).
        if(commands.isCommand(word1)) {
            return new Command(word1, word2);
        }
        else {
            return new Command(null, word2); 
        }
    }


    /**
     * Return a list of all valid commands.
     * @return The valid commands, as a string.
     */
    public String getCommands()
    {
        return commands.getCommands();
    }
}
