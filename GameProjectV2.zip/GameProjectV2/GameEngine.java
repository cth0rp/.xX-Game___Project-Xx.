import java.util.*;
/**
 * By Chrisotpher Thorp
 * By Oliver CZ
 */

public class GameEngine 
{
    // The user interface.
    private UserInterface ui;
    // The input parser.
    private Parser parser;
    // The current room.
    
    private Room currentRoom;
    private Room outside, darkRoom, lockerRoom, generatorRoom, toolRoom;
    private String nowHere;
    private ArrayList<String> inventory; 
    private ArrayList<String> roomItems;    
    /**
     * Create the game and initialise its internal map.
     */
    public GameEngine() 
    {
        createRooms();
        parser = new Parser();
        inventory = new ArrayList<>();
        roomItems = new ArrayList<>();
    }
    
    /**
     * Print out the opening message for the player.
     */
    public void printWelcome()
    {
        
        ui.println();
        ui.println("On the Morning of 14 May 1986, you and your friends decided to go visit an abandoned mine.");
        ui.println("While you were there, your friend dared you to go jump into the cart by the entrance of the mine.");
        ui.println("Just as you were waiting for him to take a photo of you in the cart, the cart suddenly began descending.");
        ui.println("When you finally realized the cart was moving it was too late and you were speeding down the mine rails");
        ui.println("As you were going down the mine you were hit by a rock on the ceiling of the rail and fell unconscious.");
        ui.println("You also broke some of the rails on you're way down, so you will need to find another way of escaping the mine.");
        ui.println("Your friends are worried, but the real question is, will you be able escape the mine?");
        ui.println();
        ui.println("Type 'help' if you need help.");
        ui.println(currentRoom.getLongDescription());
        ui.showImage(currentRoom.getImage());
        
    }

    /**
     * Set the user interface.
     * @param ui The user interface.
     */
    public void setInterface(UserInterface ui)
    {
        this.ui = ui;
    }

    /**
     * Create all the rooms and link their exits together.
     */
    private void createRooms()
    {
       
        //create new rooms
            outside = new Room("in the common area of mine", "images/mineshaft.jpg");
	        darkRoom = new Room("in a dark room and cannot see anything. Try and find a torch to search this room", "images/mineDarkRoom.jpg");	        
	        lockerRoom = new Room("in a locker room in the mine. There could be valuable items in these lockers if you have the keys", "images/mineLockers.jpg");	
	        generatorRoom = new Room("in the generator room. Repair this generator to take the minecart out of the mine", "images/mineGenerator.jpg");
        
       // initialise room exits 	
	        outside.setExit("west", darkRoom);		        
	        outside.setExit("east", lockerRoom);		       
            outside.setExit("south", generatorRoom);	     
        //outside.setExit("southWest", toolRoom);	

            lockerRoom.setExit("west", outside);	         
	        darkRoom.setExit("east", outside);		            
	        generatorRoom.setExit("north", outside);	    
	        //toolRoom.setExit("northEast", outside);	
	        currentRoom = outside;  
	    }
    private String askUserPlaceToSearch(String search) { 
        return search;
    }
     private void searchPlace (Command command) 
    {
        if(!command.hasSecondWord()) {
            ui.println("     Inventory, Room");
            return;
        }
        else  {
            String placeToSearch = command.getSecondWord();
            returnPlaceSearch(placeToSearch);
            
        }
    }
        private void returnPlaceSearch(String placeSearch) {
        
        String search = placeSearch;
        search = search.toLowerCase();
        
       // ArrayList returnValue = emptyArrayList;
        
    if (search.equals("inventory")) {
       ui.println("The items in your inventory are " + inventory);
    } else if (search.equals("room")) {
       ui.println("The items in the room are " + roomItems);
    }
    else {
        ui.println("I cannot search " + search);
     
    }
    }
    private void addToInventory(String item) {
       inventory.remove(item);
    }
    private void removeFromInventory(String item) {
       inventory.add(item);
    }
    /**
     * Given command input, interpret (that is: execute) the command.
     * @param commandLine The command to be processed.
     * @return true If the command ends the game, false otherwise.
     */
    public boolean interpretCommand(String commandLine) 
    {
        Command command = parser.getCommand(commandLine);
        
        // Whether to quit following the command.
        boolean wantToQuit = false;
        
        if(command.isUnknown()) 
        {
            ui.println("  I don't know what you mean...");
            return false;
        }

        String commandWord = command.getCommandWord();
        
        commandWord = commandWord.toLowerCase();
        
        if (commandWord.equals("help"))
        {
            printHelp();
        }
        else if (commandWord.equals("go"))
        {
            goRoom(command);
        }
        else if (commandWord.equals("quit")) 
        {
            wantToQuit = quit(command);
        }
        else if (commandWord.equals("search")) 
        {
            searchPlace(command);
            
        }
        
        
        
        // else command not recognised.
        return wantToQuit;
    }

    // implementation of user commands:

    /**
     * Print out some help information.
     * Here we print a message and a list of the 
     * command words.
     */
    private void printHelp() 
    {
        ui.println("  Your goal is to get out of the mine as quickly as possible");
        ui.println();
        ui.println("  Your command words are:");
        ui.println(parser.getCommands());
    }

    /** 
     * Try to go in to one direction. If there is an exit, enter the new
     * next room, otherwise print an error message.
     */
    private void goRoom(Command command) 
    {
        if(!command.hasSecondWord()) {
            // if there is no second word, we don't know where to go...
            ui.println("  Go where?");
            return;
        }

        String direction = command.getSecondWord();

        // Try to leave current room.
        Room nextRoom = currentRoom.getExit(direction);

        if (nextRoom == null) {
            ui.println("  There is no door!");
        }
        else 
        {
            currentRoom = nextRoom;
            ui.println(currentRoom.getLongDescription());
            ui.showImage(currentRoom.getImage());
            nowHere = currentRoom.getShortDescription();
        }
        }
    /** 
     * "Quit" was entered. Check the rest of the command to see
     * whether we really quit the game.
     * @return true, if this command quits the game, false otherwise.
     */
    private boolean quit(Command command) 
    {
        if(command.hasSecondWord()) 
        {
            ui.println("  Quit what?");
            return false;
        }
        else 
        {
            ui.println("  Thank you for playing.  Good bye.");
            return true;  // signal that we want to quit
        }
    }
    }
