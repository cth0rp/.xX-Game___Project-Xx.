import java.util.*;
/**
 * By Christopher Thorp and Oliver CZ
 */
public class RoomItems
{
    private ArrayList<String> itemsOutside;
    private ArrayList<String> itemsDarkRoom;
    private ArrayList<String> itemsLockedRoom;
    private ArrayList<String> itemsGeneratorRoom;
    private ArrayList<String> itemsLockerRoom;
    private ArrayList<String> itemsLocker;
    
    public RoomItems()
    {
        itemsOutside = new ArrayList<>();
        itemsDarkRoom = new ArrayList<>();
        itemsLockedRoom = new ArrayList<>();
        itemsGeneratorRoom = new ArrayList<>();
        itemsLockerRoom = new ArrayList<>();
        itemsLocker = new ArrayList<>();
    }
    
}
