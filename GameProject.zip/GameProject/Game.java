
/**
 * By Christopher Thorp
 * By Oliver CZ
 */
public class Game
{
	private UserInterface ui;
	private GameEngine engine;

    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
		engine = new GameEngine();
		ui = new VisualInterface(engine);
		engine.setInterface(ui);
    }
    
    /**
     * Play the game.
     */
    public void play()
    {
        ui.takeControl();
    }
}
